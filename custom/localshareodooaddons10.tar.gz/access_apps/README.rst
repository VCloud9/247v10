Control access to Apps
======================

Adds "Show Apps Menu" tick in user's access rights tab. It allows to configure administrators which don't have access to Apps.

Tested on 9.0 eaed775ee2ef601ffac8dbbeeb5d15f9763a083e

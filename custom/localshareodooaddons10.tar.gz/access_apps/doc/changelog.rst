.. _changelog:

Updates
=======

`1.0.1`
-------

- FIX: updates for recent odoo 9.0
- IMP: apps dashboard can be showed if user has access 'Show Apps Menu'


# -*- coding: utf-8 -*-
from . import ir_actions
from . import ir_translation
from . import publisher_warranty_contract
from . import ir_config_parameter
from . import web_planner
from . import ir_ui_view

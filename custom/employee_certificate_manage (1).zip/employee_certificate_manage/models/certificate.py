# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Certificate(models.Model):
    _name = 'certificate.name'
    _description = 'Certificate Name'

    @api.multi
    @api.depends()
    def _get_cert(self):
        emp_certi_obj = self.env['employee.certificate']
        for rec in self:
            emp_certi_ids = emp_certi_obj.search([('certificate_id', '=', rec.id)])
            rec.certificate_ids = emp_certi_ids.ids
    
    name = fields.Char(
        string='Name',
        required=True
    )
    certificate_ids = fields.Many2many(
        'employee.certificate',
        compute='_get_cert',
        string='Employee Certificates'
    )

# -*- coding: utf-8 -*-

import datetime as DT
import datetime
from datetime import date
import time

from odoo import models, fields, api
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

class EmployeeCertificate(models.Model):
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _name = 'employee.certificate'
    _rec_name = 'employee_id'
    _description = 'Employee Certificate'
    
    certificate_id = fields.Many2one(
        'certificate.name',
        string='Name of Certificate',
        required=True,
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Certification Partner',
        required=True,
    )
    employee_id = fields.Many2one(
        'hr.employee',
        string='Employee',
        required=True,
    )
    certification_date = fields.Date(
        string='Certificate Date'
    )
    desc = fields.Text(
        string='Description/Requirement',
    )
    certfication_exp_date = fields.Date(
        string='Certification Expiration Date'
    )
    first_days_reminder = fields.Float(
        string='First Reminder (Days)'
    )
    second_days_reminder = fields.Float(
        string='Second Reminder (Days)'
    )
    company_id = fields.Many2one(
        'res.company', 
        required=True, 
        default=lambda self: self.env.user.company_id, 
        string='Company', 
        readonly=True
    )
    user_id = fields.Many2one(
        'res.users',
        string='Created by',
        default=lambda self: self.env.user,
        readonly=True
    )
    
    @api.multi
    def run_first_days_reminder(self):
        ir_model_data = self.env['ir.model.data']
        template_pool = self.env['mail.template']
        mail_obj = self.env['mail.mail']
        certificates = self.search([])
        for certificate in certificates:
            certfication_exp_date = datetime.datetime.strptime(certificate.certfication_exp_date, '%Y-%m-%d')
            first_reminder = certfication_exp_date - DT.timedelta(days=certificate.first_days_reminder)
            first_reminder = datetime.date.strftime(first_reminder, '%Y-%m-%d')
            today = date.today().strftime('%Y-%m-%d')
            if today == first_reminder:
                template_id = self.env.ref('employee_certificate_manage.email_template_first_days_reminder')
                if template_id:
                    template_id.send_mail(certificate.id)
    
    @api.multi
    def run_second_days_reminder(self):
        ir_model_data = self.env['ir.model.data']
        template_pool = self.env['mail.template']
        mail_obj = self.env['mail.mail']
        certificates = self.search([])
        import time
        for certificate in certificates:
            certfication_exp_date = datetime.datetime.strptime(certificate.certfication_exp_date, '%Y-%m-%d')
            second_reminder = certfication_exp_date - DT.timedelta(days=certificate.second_days_reminder)
            second_reminder = datetime.date.strftime(second_reminder, '%Y-%m-%d')
            today = date.today().strftime('%Y-%m-%d')
            if today == second_reminder:
                template_id = self.env.ref('employee_certificate_manage.email_template_second_days_reminder')
                if template_id:
                    template_id.send_mail(certificate.id)
        

# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ReportEmployeeHours(models.Model):

    _name = 'report.employee.hours'
    _description = 'Employee Hours'

    report_id = fields.Many2one(
        string = 'Daily Report',
        comodel_name = 'job.daily.report',
    )

    type = fields.Selection([('employee', 'Employee'),
         ('prevailing', 'Prevailing'),
         ('standby', 'Standby'),
         ('rates', 'Rates'),
         ('all', 'All')],
         string = 'Type',
         required = True,
    )

    cost_code_id = fields.Many2one(
        string = 'Cost Code',
        comodel_name = 'job.cost.code',
    )

    employee_id = fields.Many2one(
        string = 'Employee',
        required = True,
        comodel_name = 'hr.employee'
    )

    job_class_id = fields.Many2one(
        string = 'Class',
        comodel_name = 'job.class'
    )

    shop_time_start = fields.Float(
        string = 'Shop Start',
    )

    shop_time_start_str = fields.Char(
        string = 'Shop Start',
    )

    shop_time_end = fields.Float(
        string = 'Shop End',
    )

    shop_time_end_str = fields.Char(
        string = 'Shop End',
    )

    driver_time_start = fields.Float(
        string = 'Driver Out',
    )

    driver_time_start_str = fields.Char(
        string = 'Driver Out',
    )

    driver_time_arrive = fields.Float(
        string = 'On Site',
    )

    driver_time_arrive_str = fields.Char(
        string = 'On Site',
    )

    lunch = fields.Boolean(
        string = 'Lunch',
    )

    driver_time_depart = fields.Float(
        string = 'Off Site',
    )

    driver_time_depart_str = fields.Char(
        string = 'Off Site',
    )

    driver_time_end = fields.Float(
        string = 'Driver Back',
    )

    driver_time_end_str = fields.Char(
        string = 'Driver Back',
    )

    total_regular_hours = fields.Float(
        string = 'Regular Hours',
    )

    total_passenger_hours = fields.Float(
        string = 'Passenger Hours',
    )

    total_drive_hours = fields.Float(
        string = 'Driving Hours',
    )

    total_pw_hours = fields.Float(
        string = 'PW Hours',
    )

    total_standby_hours = fields.Float(
        string = 'Standby Hours',
    )

    total_hours = fields.Float(
        string = 'Standby Hours',
    )

    per_diem = fields.Float(
        string = 'Per Diem',
    )

    timesheet_cost = fields.Float(
        string = 'Timesheet Rate',
    )

    passenger_cost = fields.Float(
        string = 'Passenger Rate',
    )

    driving_cost = fields.Float(
        string = 'Driving Rate',
    )

    pw_cost = fields.Float(
        string = 'PW Rate',
    )

    standby_cost = fields.Float(
        string = 'Standby Rate',
    )

    approved = fields.Boolean(
        string = 'Approved',
    )

    standby_reason = fields.Char(
        string = 'Reason',
    )







class JobDailyReport(models.Model):

    _name = 'job.daily.report'
    _inherit = ['mail.thread',]
    _description = 'Job Daily Reports'

    state = fields.Selection(
        string = 'State',
        selection = [
         ('draft', 'Draft'),
         ('submitted', 'Submitted'),
         ('reviewed', 'Reviewed'),
         ('approved', 'Approved'),
         ('paid', 'Paid'),
         ('cancelled', 'Cancelled'),
        ],
        required = True,
        default = 'draft',
    )

    @api.multi
    def action_submit(self):
        self.write({'state': 'submitted'})

    @api.multi
    def action_review(self):
        self.write({'state': 'reviewed'})

    @api.multi
    def action_approve(self):
        self.write({'state': 'approved'})

    @api.multi
    def action_pay(self):
        self.write({'state': 'paid'})

    @api.multi
    def action_cancel(self):
        self.write({'state': 'cancelled'})

    @api.multi
    def action_draft(self):
        self.write({'state': 'draft'})


    name = fields.Char(
        string = 'Name',
        required = True,
    )

    date = fields.Date(
        string = 'Name',
        required = True,
    )

    project_id = fields.Many2one(
        string = 'Job Project',
        comodel_name = 'project.project',
        required = True,
        domain = "[('project_type','=','subscription')]"
    )

    customer_id = fields.Many2one(
        string = 'Customer',
        comodel_name = 'res.partner',
        related = 'project_id.partner_id',
    )

    job_id = fields.Many2one(
        comodel_name = 'project.project',
        string = 'Job',
        required = True,
        domain = "[('project_type','=','job'),('partner_id','=',customer_id)]"
    )


    site_id = fields.Many2one(
        string = 'Site',
        comodel_name = 'res.partner',
        related = 'job_id.site_id',
    )

    site_reference = fields.Char(
        string = 'Site Reference',
        related = 'site_id.ref',
    )

    crew_id = fields.Many2one(
        comodel_name = 'job.crew',
        string = 'Job Crew',
    )

    crew_employees = fields.Many2many(
        comodel_name = 'hr.employee',
        string = 'Crew Members',
        related = 'crew_id.employee_ids',
    )


    # Automatically add Employees
    @api.onchange('crew_employees')
    def crew_employees_change(self):

        employee_hours = []
        prevailing_hours = []
        standby_hours = []
        all_hours = []
        rates = []

        for employee in self.crew_employees:
            employee_hours.append([0,0,
                {'type': 'employee',
                 'job_class_id': 1,
                 'cost_code_id': 1,
                 'employee_id': employee.id,}])
            prevailing_hours.append([0,0,
                {'type': 'prevailing',
                 'job_class_id': 1,
                 'cost_code_id': 1,
                 'employee_id': employee.id,}])
            standby_hours.append([0,0,
                {'type': 'standby',
                 'job_class_id': 1,
                 'cost_code_id': 1,
                 'employee_id': employee.id,}])
            all_hours.append([0,0,
                {'type': 'standby',
                 'job_class_id': 1,
                 'cost_code_id': 1,
                 'employee_id': employee.id,}])
            rates.append([0,0,
                {'type': 'standby',
                 'job_class_id': 1,
                 'cost_code_id': 1,
                 'employee_id': employee.id,}])


        return {'value': {'employee_hours': employee_hours, 'prevailing_hours': prevailing_hours, 
                          'standby_hours': standby_hours, 'all_hours': all_hours, 'rates': rates,}}

    county_id = fields.Many2one(
        string = 'County',
        comodel_name = 'res.state.county',
        related = 'site_id.county_id',
    )

    weather_id = fields.Many2many(
        string = 'Weather',
        comodel_name = 'job.weather.type',
        required = False,
    )

    structure_type_id = fields.Many2one(
        string = 'Structure Type',
        comodel_name = 'job.structure.type',
        required = True,
    )

    hotel_name = fields.Char(
        string = 'Hotel Name',
    )

    project_manager_id = fields.Many2one(
        string = 'Project Manager',
        comodel_name = 'hr.employee',
    )

    foreman_id = fields.Many2one(
        string = 'Foreman',
        comodel_name = 'hr.employee',
    )

    vehicle_ids = fields.Many2many(
        string = 'Vehicles',
        comodel_name = 'fleet.vehicle',
        relation = 'job_daily_report_fleet_vehicle_rel',
        column1 = 'job_daily_report_id',
        column2 = 'fleet_vehicle_id',
    )

    task_type_ids = fields.Many2many(
        string = 'Items/Tasks Completed',
        comodel_name = 'job.task.type',
        relation = 'job_daily_report_task_type_rel',
        column1 = 'job_daily_report_id',
        column2 = 'task_type_id',
    )

    notes = fields.Text(
        name = 'Notes',
    )

    foreman_signature = fields.Binary(
        string='Approved By',
    )

    foreman_signature_date = fields.Date(
        string='Date',
    )

    project_manager_signature = fields.Binary(
        string='Approved By',
    )

    project_manager_signature_date = fields.Date(
        string='Date',
    )


    employee_hours = fields.One2many(
        string = 'Employee Hours',
        comodel_name = 'report.employee.hours',
        inverse_name = 'report_id',
        domain = [('type','=','employee')]
    )

    prevailing_hours = fields.One2many(
        string = 'Prevailing Hours',
        comodel_name = 'report.employee.hours',
        inverse_name = 'report_id',
       domain = [('type','=','prevailing')]
    )

    standby_hours = fields.One2many(
        string = 'Standby Hours',
        comodel_name = 'report.employee.hours',
        inverse_name = 'report_id',
        domain = [('type','=','standby')]
    )

    all_hours = fields.One2many(
        string = 'Prevailing Hours',
        comodel_name = 'report.employee.hours',
        inverse_name = 'report_id',
       domain = [('type','=','all')]
    )

    rates = fields.One2many(
        string = 'Rates',
        comodel_name = 'report.employee.hours',
        inverse_name = 'report_id',
        domain = [('type','=','rates')]
    )


    _sql_constraints = [
        ('name_date_uniq', 'unique (date,name)', 'This Report is already in the system for the date entered!  Please check the Date and Name and try again.')
    ]

    @api.multi
    def action_view_projects(self):
        return {
                "type": "ir.actions.act_window",
                "res_model": "project.project",
                "res_id": self.project_id.id,
                "domain": [["id", "=", self.project_id.id]],
                "views": [[self.env.ref('project.edit_project').id, "form"]],
                "name": "Projects",
        }

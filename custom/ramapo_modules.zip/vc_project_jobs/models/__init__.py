# -*- coding: utf-8 -*-

from . import res_state_county
from . import res_partner
from . import job_class
from . import job_prevailing_wage
from . import job_cost_code
from . import job_crew
from . import job_structure_type
from . import job_task_type
from . import job_weather_type
from . import job_daily_report
from . import project_task
from . import account_analytic_account
from . import project_project
from . import sale_subscription


==========================
Clear access rights button
==========================

There is an inheritance in access right groups. Some time you try untick something,
but after clicking "Save" button you get tick back. 
In that case it's better to untick all rights and start access rights configuration from scratch. 
This module helps to do it.

Credits
=======

Contributors
------------
* krotov@it-projects.info

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`_

Further information
===================

HTML Description: https://apps.odoo.com/apps/modules/9.0/res_users_clear_access_rights/

Tested on Odoo 9.0 2ec9a9c99294761e56382bdcd766e90b8bc1bb38

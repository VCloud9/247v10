# -*- coding: utf-8 -*-

import employee_certificate
import certificate
import hr

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

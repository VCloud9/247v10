# -*- coding: utf-8 -*-
# © 2012-2013 Akretion Sébastien BEAU,David Beal,Alexis de Lattre
# © 2016 Sodexis
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import models

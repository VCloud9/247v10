# -*- encoding: utf-8 -*-

from . import mgmtsystem_kpi

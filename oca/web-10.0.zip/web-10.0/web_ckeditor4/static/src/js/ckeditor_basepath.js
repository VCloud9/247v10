CKEDITOR_BASEPATH='/web_ckeditor4/static/lib/ckeditor/'
